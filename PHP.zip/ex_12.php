<?php
$grades = array('egoing' => 10, 'k8805' => 6, 'sorialgi' => 8);
foreach($grades as $key => $value){
  echo "key : {$key} value: {$value}<br />";
}
 ?>
