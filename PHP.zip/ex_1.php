
<?php
echo "Hello world";
?>
