<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    echo $_GET['id']."님 안녕하세요."; 
    ?>

  </body>
</html>
