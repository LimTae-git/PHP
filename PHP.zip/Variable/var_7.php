<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    # 가변변수
    $title = 'subject';
    $$title = 'PHP tutorial';
    echo $subject;
     ?>

  </body>
</html>
