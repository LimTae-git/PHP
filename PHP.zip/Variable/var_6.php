<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <?php
    # 변수에 담긴 데이터 형을 검사하고 변경
    $a = 100;
    echo gettype($a); # 데이터 형 검사
    settype($a, 'double');  # 데이터 형 변경
    echo '<br />';
    echo gettype($a);
     ?>

  </body>
</html>
