<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    define('TITLE', 'PHP Tutorial');
    echo TITLE;
    define('TITLE', 'JAVA Tutorial');

     ?>

  </body>
</html>
