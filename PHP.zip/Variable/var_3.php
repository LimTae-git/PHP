<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    echo (100 + 10).'<br />';
    echo ((100 + 10)/10).'<br />';
    echo (((100 + 10)/10)-10).'<br />';
    echo ((((100 + 10)/10)-10)*10).'<br />';
    ?>

  </body>
</html>
