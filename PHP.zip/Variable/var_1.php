<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    $a=1;
    echo $a+1;    #2
    echo "<br />";
    $a=2;
    print $a+1;   #3
     ?>
  </body>
</html>
