<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    $a =100;
    $a = $a + 10;
    print $a.'<br />';
    $a = $a / 10;
    print $a.'<br />';
    $a = $a - 10;
    print $a.'<br />';
    $a = $a * 10;
    print $a.'<br />';
    ?>

  </body>
</html>
