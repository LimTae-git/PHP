<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    $first = "coding";
    echo $first." everybody";   // . : 문자와 문자 결합
     ?>

  </body>
</html>
