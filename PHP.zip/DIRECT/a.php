<?php
echo getcwd().'<br />'; // 경로 확인
chdir('../');   // 디렉토리 변경,  .. : 현재 디렉토리의 부모디렉토리로 경로 변경
echo getcwd().'<br />';
 ?>
