<?php
$dir       = './';    // 현재 경로 지정
$files1    = scandir($dir);   // scandir 이라는 내장함수의 입력함수로 값을 줌
$files2    = scandir($dir, 1);  // scandir : 검색하는것

print_r($files1);
print_r($files2);

 ?>
