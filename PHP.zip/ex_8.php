<?php
if($_GET['id'] === 'egoing') {
  echo 'right';
} else {
  echo 'wrong';
}
?>
