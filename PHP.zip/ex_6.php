<?php
echo $_POST['id'].','.$_POST['password'];
 ?>
