<?php
$file = './writeme.txt';
file_put_contents($file, 'coding everybody');
 ?>
