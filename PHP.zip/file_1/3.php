<?php
$file = './readme.txt';
echo file_get_contents($file);
 ?>
