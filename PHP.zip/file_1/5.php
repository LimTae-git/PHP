<?php
$homepage = file_get_contents('https://www.naver.com');
echo $homepage;
 ?>
