<?php
unlink('deleteme.txt');
?>
