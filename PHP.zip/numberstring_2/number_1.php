<?php
var_dump(6);
 ?>
