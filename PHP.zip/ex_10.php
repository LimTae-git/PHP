<?php
if($_POST['id'] === 'egoing' && $_POST['password'] === '111111'){
  echo 'right';
} else {
  echo 'wrong';
}
?>
