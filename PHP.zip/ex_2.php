<html>
<body>
  echo "Hello world"
  <?php
  echo "Hello world";
   ?>
</body>
</html>
